-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `dispositivos`;
CREATE TABLE `dispositivos` (
  `empresa_id` int(11) NOT NULL,
  `dispositivo_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dispositivo_id`),
  KEY `empresa_id` (`empresa_id`),
  CONSTRAINT `dispositivos_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`empresa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `dispositivos` (`empresa_id`, `dispositivo_id`, `nombre`) VALUES
(1,	1,	'dispositivo1'),
(2,	2,	'dispositivo1'),
(1,	3,	'dispositivo2'),
(2,	4,	'dispositivo2');

DROP TABLE IF EXISTS `empresas`;
CREATE TABLE `empresas` (
  `empresa_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`empresa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `empresas` (`empresa_id`, `nombre`) VALUES
(1,	'empresa1'),
(2,	'empresa2');

DROP TABLE IF EXISTS `temperaturas`;
CREATE TABLE `temperaturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `sensor1` float NOT NULL,
  `sensor2` float NOT NULL,
  `sensor3` float NOT NULL,
  `sensor4` float NOT NULL,
  `id_dispositivo` int(11) NOT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_dispositivo` (`id_dispositivo`),
  KEY `id_empresa` (`id_empresa`),
  CONSTRAINT `temperaturas_ibfk_1` FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivos` (`dispositivo_id`),
  CONSTRAINT `temperaturas_ibfk_2` FOREIGN KEY (`id_empresa`) REFERENCES `empresas` (`empresa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `temperaturas` (`id`, `fecha`, `sensor1`, `sensor2`, `sensor3`, `sensor4`, `id_dispositivo`, `id_empresa`) VALUES
(1,	'2018-04-09 17:45:51',	2,	66,	22,	20,	4,	2),
(2,	'2018-04-10 15:15:49',	12,	44,	12,	12,	2,	2),
(3,	'2018-04-10 15:17:06',	42,	64,	84,	24,	2,	1),
(4,	'2018-04-11 13:16:18',	14,	88,	64,	0,	3,	1),
(5,	'2018-04-11 15:18:48',	88,	50,	3,	4,	1,	1);

-- 2018-04-27 14:03:41
